let menu = document.querySelector('#mobile');

let links = document.querySelector('.header__menu');

    menu.addEventListener('click', function() {
    menu.classList.toggle('is-active');
    links.classList.toggle('active');
});

let alinks = document.querySelectorAll(".header__menu .header__item a");
    alinks.forEach(alink => {
    alink.addEventListener('click', function() {
        menu.classList.toggle('is-active');
    links.classList.toggle('active');
    })
})

let logo = document.querySelector("#header__logo");
    console.log(logo);
    logo.addEventListener('click', function() {
        if((menu.parentElement.children.item(0).classList.contains('is-active')))
        {
            if((menu.parentElement.children.item(2).classList.contains('active')))
            {
                console.log('yes');
                menu.classList.toggle('is-active');
                links.classList.toggle('active');
            }
        }
        
    })

// let logo= document.querySelector("#skills .skills__logos .logo .logo__content");
// console.log(logo);
// logo.addEventListener('mouseenter', function(event) {
//     // let p = logo.children.item(1);
//     // p.style.display="block";
//     // p.style.animation = "up 0.3s alternate";
//     // logo.addEventListener('mouseleave', function(event){
//     //     p.style.display="none";
//     //     logo.style.animation = "down 0.5s alternate";
//     // })
// })